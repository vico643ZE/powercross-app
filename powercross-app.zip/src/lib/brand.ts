export const brand = {
  name: 'Powercross',
  colors: {
    primary: '#0f172a',
    accent: '#22c55e',
  },
  logoText: 'Powercross',
}
